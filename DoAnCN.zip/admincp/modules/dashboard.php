<p>Thống kê đơn hàng theo : <span id="text-date"></span> </p>
<p>
    <select class="select-date" name="" id="">
        <option value="7ngay">7 ngày</option>
        <option value="28ngay">28 ngày</option>
        <option value="90ngay">90 ngày</option>
        <option value="365ngay">365 ngày</option>
    </select>
</p>
<div id="chart" style="height: 250px;"></div>