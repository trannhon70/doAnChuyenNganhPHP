<p>Thêm danh mục bài viết</p>
<table style="border: 1px; width: 50%; border-collapse: collapse;">
    <form action="modules/quanlydanhmucbaiviet/xuly.php" method="post">
        <tr>
            <td>Tên danh mục bài viết</td>
            <td><input type="text" name="tendanhmucbaiviet"> </td>
        </tr>
        <tr>
            <td>Thứ tự</td>
            <td><input type="text" name="thutu"> </td>
        </tr>
        <tr colspan="2">
            <td><input type="submit" name=themdanhmucbaiviet value="Thêm danh mục bài viết "> </td>
        </tr>
    </form>

</table>