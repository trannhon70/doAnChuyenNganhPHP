<p>Thêm danh mục sản phẩm</p>
<table style="border: 1px; width: 50%; border-collapse: collapse;">
    <form action="modules/quanlydanhmucsp/xuly.php" method="post">
        <tr>
            <th>Điền danh mục sản phẩm</th>
        </tr>
        <tr>
            <td>Tên danh mục</td>
            <td><input type="text" name="tendanhmuc"> </td>
        </tr>
        <tr>
            <td>Thứ tự</td>
            <td><input type="text" name="thutu"> </td>
        </tr>
        <tr colspan="2">
            <td><input type="submit" name=themdanhmuc value="Thêm danh mục sản phẩm "> </td>
        </tr>
    </form>

</table>