
<?php
    require ('../Carbon/autoload.php');
    use Carbon\Carbon;

    printf("Now: %s", Carbon::now('Asia/Ho_Chi_Minh'));
?>